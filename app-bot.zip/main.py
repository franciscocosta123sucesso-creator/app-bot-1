from aiogram import Bot, Dispatcher, executor, types

TOKEN = "COLE_SEU_TOKEN_AQUI"

bot = Bot(token=TOKEN)
dp = Dispatcher(bot)

@dp.message_handler(commands=['start'])
async def start(message: types.Message):

    kb = types.ReplyKeyboardMarkup(resize_keyboard=True)
    kb.add("🛍 Catálogo")
    kb.add("👤 Perfil", "🛒 Compras")
    kb.add("📞 Suporte")

    await message.answer("👋 Bem-vindo à sua loja automática!", reply_markup=kb)

@dp.message_handler(lambda m: m.text == "🛍 Catálogo")
async def catalog(message: types.Message):
    await message.answer("""📦 PRODUTOS DISPONÍVEIS

1 - CANVA PRO | R$10
2 - EXCEL AVANÇADO | R$15
3 - PACOTE OFFICE | R$20
""")

@dp.message_handler(lambda m: m.text == "👤 Perfil")
async def profile(message: types.Message):
    await message.answer(f"👤 ID: {message.from_user.id}\n💰 Saldo: R$0")

@dp.message_handler(lambda m: m.text == "🛒 Compras")
async def orders(message: types.Message):
    await message.answer("🛒 Você ainda não fez compras.")

@dp.message_handler(lambda m: m.text == "📞 Suporte")
async def support(message: types.Message):
    await message.answer("📞 Suporte em breve.")

if __name__ == "__main__":
    executor.start_polling(dp, skip_updates=True)
